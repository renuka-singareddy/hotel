package com.hotelapplication.exception;

public class HotelException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 726264577455921591L;

	public HotelException(String message) 
	{
		
		super(message);
		
	}
}


package com.hotelapplication.pl;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Iterator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.hotelapplication.bean.HotelBean;
import com.hotelapplication.exception.HotelException;
import com.hotelapplication.service.HotelServiceImpl;
import com.hotelapplication.service.IHotelservice;

public class HotelMain {
	
	     static Scanner sc = new Scanner(System.in);
	     static IHotelservice hotelservice = null;
		 static HotelServiceImpl hotelServiceImpl = null;
		static Logger logger=Logger.getRootLogger();
		

		public static void main(String[] args) {
			PropertyConfigurator.configure("resources//log4j.properties");
			HotelBean hotelBean = null;

			int customerId = 0;
			int option = 0;

			while (true) {

				// show menu
				System.out.println();
				System.out.println();
				System.out.println("   HOTEL MANAGEMENT ");
				System.out.println("_______________________________\n");

				System.out.println("1.Add customer ");
				System.out.println("2.View customer");
				System.out.println("3.Exit");
				System.out.println("________________________________");
				System.out.println("Select an option:");
				// accept option

				try {
					option = sc.nextInt();

					switch (option) {

					case 1:

						while (hotelBean == null) {
							hotelBean = populateHotelBean();
							// System.out.println(donorBean);
						}

						try {
							hotelservice = new HotelServiceImpl();
							customerId = hotelservice.addCustomerDetails(hotelBean);

							System.out.println("Customer details  has been successfully registered ");
							System.out.println("Customer  ID Is: " + customerId);

						} catch (HotelException hotelException) {
							logger.error("exception occured", hotelException);
							System.out.println("ERROR : "
									+ hotelException.getMessage());
						} finally {
							customerId = 0;
							hotelservice = null;
							hotelBean = null;
						}

						break;

					case 2:

						hotelServiceImpl = new HotelServiceImpl();

						System.out.println("Enter customer id:");
						customerId = sc.nextInt();

					/*	while (true) {
							if (hotelServiceImpl.validateCustomer(hotelBean)) {
								break;
							} else {
								System.err.println("Please enter numeric customer id only try again");
																customerId = sc.nextInt();
							}
						}*/

						hotelBean = getCustomerDetails(customerId);

						if (hotelBean != null) {
							System.out.println("Name             :"
									+ hotelBean.getCustomerName());
							System.out.println("Phone          :"
									+ hotelBean.getPhone());
							System.out.println("Email     :"
									+ hotelBean.getEmail());
							System.out.println("Ckeck in       :"
									+ hotelBean.getCheckIn());
							System.out.println("Check out  :"
									+ hotelBean.getCheckOut());
						} else {
							System.err
									.println("There are no customer details associated with customer id "
											+ customerId);
						}

						break;

					

					case 3:

						System.out.print("Exit hotel Application");
						System.exit(0);
						break;
					default:
						System.out.println("Enter a valid option[1-4]");
					}// end of switch
				}

				catch (InputMismatchException e) {
					sc.nextLine();
					System.err.println("Please enter a numeric value, try again");
				}

			}// end of while
		}// end of try

		private static HotelBean populateHotelBean() {
			HotelBean bean = null;
			// TODO Auto-generated method stub
			return bean;
		}

		/*
		 * This function will call the service layer method and return the bean
		 * object which is populated by the information of the given donorId in
		 * parameter
		 */
		private static HotelBean getCustomerDetails(int customerId) {
			HotelBean hotelBean = null;
			hotelservice = new HotelServiceImpl();

			try {
				hotelBean = hotelservice.viewCustomerDetails(customerId);
			} catch (HotelException hotelException) {
				logger.error("exception occured ", hotelException);
				System.out.println("ERROR : " + hotelException.getMessage());
			}

			 finally {
					customerId = 0;
					hotelservice = null;
					hotelBean = null;
				}
			return hotelBean;
			
		}

		/*
		 * This function will be called by main and will return a validated bean
		 * object OR null if details are invalid
		 */
		private static HotelBean populateHotelBean1() {

			// Reading and setting the values for the donorBean
			
			HotelBean hotelBean = new HotelBean();
			System.out.println("\n Enter Details");

			System.out.println("Enter customer name: ");
			hotelBean.setCustomerName(sc.next());

			System.out.println("Enter phone number: ");
			hotelBean.setPhone(sc.nextLong());

			System.out.println("Enter email: ");
			hotelBean.setEmail(sc.next());

			System.out.println("Enter chek in date: ");
			hotelBean.setCheckIn(sc.next());
			
			System.out.println("Enter chek out date: ");
			hotelBean.setCheckOut(sc.next());
			

			hotelServiceImpl = new HotelServiceImpl();

			/*try {
				hotelServiceImpl.validateCustomer(hotelBean);
				return hotelBean;
			} catch (HotelException hotelException) {
				logger.error("exception occurred", hotelException);
				System.err.println("Invalid data:");
				System.err.println(hotelException.getMessage() + " \n Try again..");
				System.exit(0);

			}*/
			return null;

		}
	}



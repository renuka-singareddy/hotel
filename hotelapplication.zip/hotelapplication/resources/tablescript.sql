CREATE TABLE Customer_Details(
Customer_Id VARCHAR2(20),
Customer_Name VARCHAR2(20),
Phone VARCHAR2(20),
Email VARCHAR2(20),
Check_In DATE,
Check_Out DATE);

CREATE SEQUENCE customerId_sequence
START WITH 1000;
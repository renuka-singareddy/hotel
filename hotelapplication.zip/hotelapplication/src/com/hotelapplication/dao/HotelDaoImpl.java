package com.hotelapplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.hotelapplication.bean.HotelBean;
import com.hotelapplication.exception.HotelException;
import com.hotelapplication.util.DBConnection;

public class HotelDaoImpl implements IHotelDao {
	
		Logger logger=Logger.getRootLogger();
		public HotelDaoImpl()
		{
		PropertyConfigurator.configure("resources//log4j.properties");
		
		}
	

		public int addCustomerDetails(HotelBean hotel) throws HotelException 
		{
			Connection connection = DBConnection.getInstance().getConnection();	
			
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			
			int customerId=0;
			
			int queryResult=0;
			try
			{		
				preparedStatement=connection.prepareStatement(IQueryMapper.INSERT_QUERY);

				preparedStatement.setInt(1,hotel.getCustomerId());
				preparedStatement.setString(2,hotel.getCustomerName());
				preparedStatement.setLong(3,hotel.getPhone());
				preparedStatement.setString(4,hotel.getEmail());
				preparedStatement.setString(5,hotel.getCheckIn());
				preparedStatement.setString(6,hotel.getCheckOut());
				
				
				
				queryResult=preparedStatement.executeUpdate();
			
				preparedStatement = connection.prepareStatement(IQueryMapper.CUSTOMERID_QUERY_SEQUENCE);
				resultSet=preparedStatement.executeQuery();

				if(resultSet.next())
				{
					customerId=resultSet.getInt(1);
							
				}
		
				if(queryResult==0)
				{
					logger.error("Insertion failed ");
					throw new HotelException("Inserting donor details failed ");

				}
				else
				{
					logger.info("Donor details added successfully:");
					return customerId;
				}

			}
			catch(SQLException sqlException)
			{
				logger.error(sqlException.getMessage());
				throw new HotelException("Tehnical problem occured refer log");
			}

			finally
			{
				try 
				{
					//resultSet.close();
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(sqlException.getMessage());
					throw new HotelException("Error in closing db connection");

				}
			}
			
			
		}


		public HotelBean viewCustomerDetails(int customerId) throws HotelException {
			
			Connection connection=DBConnection.getInstance().getConnection();
			
			
			PreparedStatement preparedStatement=null;
			ResultSet resultset = null;
			HotelBean bean=null;
			
			try
			{
				preparedStatement=connection.prepareStatement(IQueryMapper.VIEW_CUSTOMER_DETAILS_QUERY);
				preparedStatement.setInt(1,customerId);
				resultset=preparedStatement.executeQuery();
				
				if(resultset.next())
				{
					bean = new HotelBean();
					bean.setCustomerName(resultset.getString(1));
					bean.setPhone(resultset.getLong(2));
					bean.setEmail(resultset.getString(3));
					bean.setCheckIn(resultset.getString(4));
					bean.setCheckOut(resultset.getString(5));
					
				}
				
				if( bean != null)
				{
					logger.info("Record Found Successfully");
					return bean;
				}
				else
				{
					logger.info("Record Not Found Successfully");
					return null;
				}
				
			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
				throw new HotelException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultset.close();
					preparedStatement.close();
					connection.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new HotelException("Error in closing db connection");

				}
			}
			
		}



		
	}



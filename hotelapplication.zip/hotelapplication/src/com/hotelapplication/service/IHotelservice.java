package com.hotelapplication.service;

import com.hotelapplication.bean.HotelBean;
import com.hotelapplication.exception.HotelException;

public interface IHotelservice {
	public int addCustomerDetails(HotelBean hotel) throws HotelException;
	public HotelBean viewCustomerDetails(int customerId) throws HotelException;

}

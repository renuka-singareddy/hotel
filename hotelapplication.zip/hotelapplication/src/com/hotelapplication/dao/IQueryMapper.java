package com.hotelapplication.dao;

public interface IQueryMapper {
	public static final String VIEW_CUSTOMER_DETAILS_QUERY="SELECT customer_name,phone,email,checkin,checkout FROM customer_details WHERE  customer_id=?";
	public static final String INSERT_QUERY="INSERT INTO customer_details VALUES(customerId_sequence.NEXTVAL,?,?,?,SYSDATE,SYSDATE)";
	public static final String CUSTOMERID_QUERY_SEQUENCE="SELECT customerId_sequence.CURRVAL FROM DUAL";

}
